import { useState, useEffect, useRef } from "react";
import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getFirestore, doc, getDoc, setDoc, collection, getDocs,
} from "firebase/firestore";

// ============================================================
// FIREBASE CONFIG
// ============================================================
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyBqcmjlTQSSQ48rCcSz-FgNCLAg-NGI1xA",
  authDomain: "english-tracker-6a823.firebaseapp.com",
  projectId: "english-tracker-6a823",
  storageBucket: "english-tracker-6a823.firebasestorage.app",
  messagingSenderId: "1064431271403",
  appId: "1:1064431271403:web:2904301dee63123ec62dae",
};

// ============================================================
// ROUTINE DATA
// ============================================================
const ROUTINES = {
  beginner: {
    label: "مبتدئ", labelEn: "Beginner", levelEn: "A1–A2",
    color: "#6366F1", accent: "#818CF8", totalMins: 45,
    steps: [
      {
        id: "listen", icon: "🎧", title: "Listening", titleEn: "Listening",
        mins: 10, subtitle: "اسمع فيديو من مستواك",
        details: [
          "افتح فيديو قصير (5–7 دقايق) من engvid.com أو elllo.org",
          "اسمعه مرة كاملة بدون ما توقف — ركز على الفكرة العامة",
          "اسمعه مرة تانية ووقف عند كل جملة مش فاهمها",
          "اكتب الكلمات الجديدة على ورقة",
        ],
        tip: "متختارش فيديو أطول من 7 دقايق في الأول — الإحساس بالإنجاز مهم",
        sites: [{ name: "engvid.com", url: "https://www.engvid.com" }, { name: "elllo.org", url: "https://www.elllo.org" }],
        tasks: ["سمعت الفيديو مرة كاملة", "سمعته تاني مع وقفات", "كتبت الكلمات الجديدة"],
      },
      {
        id: "shadow", icon: "🗣️", title: "Shadowing", titleEn: "Shadowing",
        mins: 10, subtitle: "قلّد النطق والإيقاع",
        details: [
          "ارجع لنفس الفيديو وفعّل الـ subtitles",
          "كل جملة: اسمعها ← وقّف ← قلّدها بنفس النبرة والسرعة",
          "مش هام المعنى دلوقتي — هام إنك تحس بطريقة الكلام",
          "لو في كلمة صعبة، دور عليها على youglish.com",
        ],
        tip: "اعمل Shadowing بصوت عالي — مش في دماغك",
        sites: [{ name: "youglish.com", url: "https://youglish.com" }],
        tasks: ["قلّدت الجمل بصوت عالي", "تحققت من نطق الكلمات الصعبة"],
      },
      {
        id: "write", icon: "✍️", title: "Writing", titleEn: "Writing",
        mins: 10, subtitle: "اكتب ملخص بكلامك",
        details: [
          "اكتب ملخص الفيديو بالإنجليزي — 5 جمل كافية في الأول",
          "استخدم الكلمات الجديدة اللي كتبتها",
          "مش لازم يبقى مثالي — المهم تكتب",
          "صحح الجرامر على languagetool.org (مجاني)",
        ],
        tip: "لو مش قادر تكتب جملة — اكتبها بالعربي الأول وترجمها",
        sites: [{ name: "languagetool.org", url: "https://languagetool.org" }],
        tasks: ["كتبت ملخص 5 جمل على الأقل", "صححت الجرامر على languagetool"],
      },
      {
        id: "vocab", icon: "📖", title: "Vocabulary", titleEn: "Vocabulary",
        mins: 10, subtitle: "احفظ بالطريقة الصح",
        details: [
          "افتح Anki وأضف الكلمات الجديدة اللي لقيتها النهارده",
          "راجع الكلمات اللي Anki بيقولك عليها — مش أكتر",
          "مش محتاج تحفظ 20 كلمة — 5 كلمات كويسين جداً",
        ],
        tip: "Anki بيستخدم Spaced Repetition — أذكى طريقة للحفظ علمياً",
        sites: [{ name: "ankiweb.net", url: "https://apps.ankiweb.net" }],
        tasks: ["أضفت الكلمات الجديدة على Anki", "راجعت الـ deck بتاعي"],
      },
      {
        id: "speak", icon: "🪞", title: "Speaking", titleEn: "Speaking",
        mins: 5, subtitle: "اتكلم بصوت عالي",
        details: [
          "وقف قدام المرايه وقول ملخص الفيديو بكلامك",
          "مش لازم تقرا اللي كتبته — حاول تتكلم بتلقائية",
          "لو مش قادر — اقرا الـ writing بتاعك بصوت عالي",
          "سجّل نفسك بالموبايل واسمع نفسك",
        ],
        tip: "أول أسبوع هتحس بغرابة — ده طبيعي، استمر",
        sites: [{ name: "getpronounce.com", url: "https://getpronounce.com" }],
        tasks: ["اتكلمت قدام المرايه", "سجّلت نفسي واسمعت التسجيل"],
      },
    ],
  },
  intermediate: {
    label: "متوسط", labelEn: "Intermediate", levelEn: "B1–B2",
    color: "#7C3AED", accent: "#A78BFA", totalMins: 40,
    steps: [
      {
        id: "listen", icon: "🎧", title: "Listening بدون subtitle", titleEn: "Raw Listening",
        mins: 10, subtitle: "تدريب حقيقي",
        details: [
          "افتح podcast أو YouTube عادي (مش تعليمي) — 8–10 دقايق",
          "اسمعه مرة كاملة بدون subtitles",
          "اكتب النقط الرئيسية اللي فهمتها",
          "اسمعه تاني بالـ transcript وشوف إيه اللي فاتك",
        ],
        tip: "قنوات كويسة: Kurzgesagt, TED-Ed, Veritasium",
        sites: [{ name: "ted.com", url: "https://www.ted.com" }, { name: "youtube.com", url: "https://youtube.com" }],
        tasks: ["اسمعت بدون subtitle", "كتبت النقاط الرئيسية", "قارنت مع الـ transcript"],
      },
      {
        id: "shadow", icon: "🗣️", title: "Shadowing متقدم", titleEn: "Advanced Shadowing",
        mins: 5, subtitle: "نبرة + إيقاع + stress",
        details: [
          "اختار جزء واحد بس (دقيقتين) من الفيديو",
          "شادو نفس الجزء 3 مرات متتالية",
          "ركز على الـ word stress والـ intonation مش بس الكلمات",
        ],
        tip: "الهدف مش تبقى زي المتكلم — الهدف تبقى مفهوم وطبيعي",
        sites: [{ name: "youglish.com", url: "https://youglish.com" }],
        tasks: ["شادو نفس الجزء 3 مرات", "ركزت على الـ stress والـ intonation"],
      },
      {
        id: "write", icon: "✍️", title: "Writing — رأيك", titleEn: "Opinion Writing",
        mins: 10, subtitle: "مش ملخص — موقف",
        details: [
          "بدل ما تلخص الفيديو — اكتب رأيك فيه",
          "استخدم: I think / In my opinion / I agree because...",
          "حاول تكتب paragraph كاملة مترابطة",
          "صحح على languagetool وافهم التصحيحات",
        ],
        tip: "الـ writing ده هيتحول لـ speaking — فكر فيه كمحادثة مكتوبة",
        sites: [{ name: "languagetool.org", url: "https://languagetool.org" }],
        tasks: ["كتبت رأيي في paragraph كاملة", "صححت وفهمت التصحيحات"],
      },
      {
        id: "vocab", icon: "📖", title: "Vocabulary في السياق", titleEn: "Contextual Vocab",
        mins: 5, subtitle: "مش حفظ — استخدام",
        details: [
          "استخدم كل كلمة جديدة في جملة من عندك",
          "راجع الـ Anki deck بتاعك",
        ],
        tip: "الكلمة اللي بتستخدمها في جملة هتفضل معاك أكتر",
        sites: [{ name: "ankiweb.net", url: "https://apps.ankiweb.net" }],
        tasks: ["استخدمت الكلمات الجديدة في جمل", "راجعت الـ Anki deck"],
      },
      {
        id: "speak", icon: "🪞", title: "Speaking — بدون سكريبت", titleEn: "Free Speaking",
        mins: 10, subtitle: "محادثة حقيقية",
        details: [
          "اتكلم عن موضوع الفيديو من غير ما تقرا حاجة — دقيقتين",
          "بعدين غيّر الموضوع واتكلم عن يومك",
          "سجّل نفسك واسمع: فين وقفت؟ فين اتلخبطت؟",
          "استخدم getpronounce.com لو في كلمة مش متأكد منها",
        ],
        tip: "التسجيل مهم — مش عشان تحكم على نفسك، عشان تشوف تقدمك",
        sites: [{ name: "getpronounce.com", url: "https://getpronounce.com" }],
        tasks: ["اتكلمت دقيقتين على الأقل بدون سكريبت", "سجّلت نفسي واسمعت"],
      },
    ],
  },
  advanced: {
    label: "متقدم", labelEn: "Advanced", levelEn: "C1–C2",
    color: "#DC2626", accent: "#F87171", totalMins: 60,
    steps: [
      {
        id: "listen", icon: "🎧", title: "Deep Listening", titleEn: "Deep Listening",
        mins: 15, subtitle: "محتوى حقيقي — مرة واحدة فقط",
        details: [
          "افتح podcast أو lecture أكاديمي — 12–15 دقيقة",
          "اسمعه مرة واحدة فقط بدون وقفات أو subtitles",
          "اكتب ملخص كامل في 10 جمل على الأقل",
          "قارن ملخصك بالـ transcript واحسب نسبة الفهم",
        ],
        tip: "Podcasts كويسة: Lex Fridman, How I Built This, Hidden Brain",
        sites: [{ name: "spotify.com", url: "https://open.spotify.com" }, { name: "ted.com", url: "https://www.ted.com" }],
        tasks: ["اسمعت مرة واحدة بدون توقف", "كتبت 10 جمل ملخص", "قارنت مع الـ transcript"],
      },
      {
        id: "shadow", icon: "🗣️", title: "Advanced Mirroring", titleEn: "Advanced Mirroring",
        mins: 10, subtitle: "اتبنى نفس أسلوب المتكلم",
        details: [
          "اختار 3 دقايق من speaker محترف",
          "شادو مرة بدون نص، مرة تانية مع النص",
          "ركز على: pauses, rhythm, connected speech",
          "سجّل نفسك وقارن بالأصل",
        ],
        tip: "Connected speech هو سر الـ fluency — كلمتين بتتدمجوا في صوت واحد",
        sites: [{ name: "youglish.com", url: "https://youglish.com" }],
        tasks: ["شادو بدون نص مرة كاملة", "سجّلت وقارنت بالأصل"],
      },
      {
        id: "write", icon: "✍️", title: "Essay Writing", titleEn: "Analytical Writing",
        mins: 15, subtitle: "كتابة تحليلية منظمة",
        details: [
          "اكتب essay عن موضوع من الـ content — 200 كلمة على الأقل",
          "استخدم structure: Introduction → Body × 2 → Conclusion",
          "استخدم academic connectors: Furthermore, Nevertheless, In contrast",
          "صحح على languagetool وافهم كل تصحيح",
        ],
        tip: "مش المهم تكتب كتير — المهم تكتب منظم ومترابط",
        sites: [{ name: "languagetool.org", url: "https://languagetool.org" }],
        tasks: ["كتبت 200 كلمة على الأقل", "استخدمت الـ structure الصح", "صححت وفهمت"],
      },
      {
        id: "vocab", icon: "📖", title: "Collocations & Idioms", titleEn: "Advanced Vocab",
        mins: 10, subtitle: "مش كلمات — تعابير جاهزة",
        details: [
          "دوّر على 5 collocations أو idioms من الـ content",
          "اكتب جملة لكل واحدة في سياق طبيعي",
          "راجع الـ Anki deck بتاعك",
        ],
        tip: "'make a decision' مش 'do a decision' — ده اللي بيفرق بين native وغيره",
        sites: [{ name: "ankiweb.net", url: "https://apps.ankiweb.net" }, { name: "ozdic.com", url: "https://ozdic.com" }],
        tasks: ["لقيت 5 collocations/idioms", "كتبت جملة لكل منهم", "راجعت Anki"],
      },
      {
        id: "speak", icon: "🎤", title: "Monologue", titleEn: "Structured Monologue",
        mins: 10, subtitle: "كلام منظم ومقنع",
        details: [
          "اختار موضوع جدلي واتكلم لمدة 3 دقايق بدون توقف",
          "استخدم structure: موقفك ← دليلين ← رد على الاعتراض",
          "سجّل نفسك وارفع السجل على speechace.com للتقييم",
          "حدد: إيه اللي هتحسّنه الأسبوع الجاي؟",
        ],
        tip: "الـ C1 speaker مش بيكون بدون أخطاء — بيكون fluent ومنظم",
        sites: [{ name: "speechace.com", url: "https://speechace.com" }],
        tasks: ["اتكلمت 3 دقايق بدون توقف", "سجّلت وقيّمت نفسي"],
      },
    ],
  },
};

// ============================================================
// BADGES
// ============================================================
const BADGES = [
  { id: "first_day",        icon: "🌟", name: "البداية",        desc: "أتممت أول سيشن!",            check: (u) => (u.totalDays || 0) >= 1 },
  { id: "three_days",       icon: "🎯", name: "3 أيام",          desc: "3 أيام إجمالي",              check: (u) => (u.totalDays || 0) >= 3 },
  { id: "ten_days",         icon: "💪", name: "10 أيام",         desc: "10 أيام إجمالي",             check: (u) => (u.totalDays || 0) >= 10 },
  { id: "thirty_total",     icon: "📅", name: "شهر إجمالي",      desc: "30 يوم إجمالي",              check: (u) => (u.totalDays || 0) >= 30 },
  { id: "hundred_days",     icon: "💎", name: "100 يوم",         desc: "100 يوم إجمالي! لجندة",       check: (u) => (u.totalDays || 0) >= 100 },
  { id: "week_streak",      icon: "🔥", name: "أسبوع متتالي",    desc: "7 أيام Streak",              check: (u) => (u.streak || 0) >= 7 },
  { id: "three_week_streak",icon: "⚡", name: "21 يوم Streak",   desc: "3 أسابيع متتالية!",          check: (u) => (u.streak || 0) >= 21 },
  { id: "month_streak",     icon: "🏆", name: "شهر Streak",      desc: "30 يوم متتالي!! أسطورة",     check: (u) => (u.streak || 0) >= 30 },
  { id: "intermediate",     icon: "🚀", name: "ارتقيت!",         desc: "وصلت للمستوى المتوسط",       check: (u) => u.level === "intermediate" || u.level === "advanced" },
  { id: "advanced_level",   icon: "🎓", name: "نخبة",            desc: "وصلت للمستوى المتقدم!",      check: (u) => u.level === "advanced" },
  { id: "freeze_used",      icon: "🧊", name: "ناجي بالـ Freeze", desc: "استخدمت Streak Freeze",     check: (u) => (u.freezesUsed || 0) >= 1 },
];

function getEarnedBadges(userData) {
  if (!userData) return [];
  return BADGES.filter(b => b.check(userData));
}

// ============================================================
// FIREBASE
// ============================================================
const fbApp = getApps().length ? getApp() : initializeApp(FIREBASE_CONFIG);
const db = getFirestore(fbApp);

function buildRef(path) {
  const parts = path.split("/");
  return parts.length === 2
    ? doc(db, parts[0], parts[1])
    : doc(db, parts[0], parts[1], parts[2], parts[3]);
}

async function fbGet(path) {
  try {
    const snap = await getDoc(buildRef(path));
    return snap.exists() ? snap.data() : null;
  } catch (e) {
    console.error("Firestore get error:", e);
    return null;
  }
}

async function fbSet(path, data, merge = true) {
  try {
    await setDoc(buildRef(path), data, { merge });
    return true;
  } catch (e) {
    console.error("Firestore set error:", e);
    return false;
  }
}

async function fbGetAll(col) {
  try {
    const snap = await getDocs(collection(db, col));
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (e) {
    console.error("Firestore getAll error:", e);
    return [];
  }
}

// ============================================================
// UTILS
// ============================================================
const todayKey = () => new Date().toISOString().slice(0, 10);
const beep = () => {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.frequency.value = 880; g.gain.setValueAtTime(0.3, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
    o.start(); o.stop(ctx.currentTime + 0.6);
  } catch {}
};

// ============================================================
// TIMER HOOK
// ============================================================
function useTimer(mins) {
  const total = mins * 60;
  const [secs, setSecs] = useState(total);
  const [on, setOn] = useState(false);
  const [done, setDone] = useState(false);
  const iv = useRef(null);
  useEffect(() => {
    if (on && secs > 0) {
      iv.current = setInterval(() => setSecs(s => {
        if (s <= 1) { clearInterval(iv.current); setOn(false); setDone(true); beep(); return 0; }
        return s - 1;
      }), 1000);
    }
    return () => clearInterval(iv.current);
  }, [on]);
  const toggle = () => { if (!done) setOn(r => !r); };
  const reset = () => { clearInterval(iv.current); setOn(false); setDone(false); setSecs(total); };
  const fmt = `${String(Math.floor(secs / 60)).padStart(2, "0")}:${String(secs % 60).padStart(2, "0")}`;
  return { fmt, on, done, toggle, reset, secs, total };
}

// ============================================================
// SMALL COMPONENTS
// ============================================================
function Ring({ secs, total, color, size = 60 }) {
  const r = (size - 8) / 2, c = 2 * Math.PI * r;
  const dash = c * (total > 0 ? (total - secs) / total : 1);
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)", flexShrink: 0 }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#E5E7EB" strokeWidth={5} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={5}
        strokeDasharray={`${dash} ${c}`} strokeLinecap="round"
        style={{ transition: "stroke-dasharray 0.5s" }} />
    </svg>
  );
}

function Badge({ children, color, bg }) {
  return <span style={{ background: bg || color + "22", color, borderRadius: 20, padding: "2px 10px", fontSize: 11, fontWeight: 700 }}>{children}</span>;
}

function Btn({ children, onClick, color = "#6366F1", disabled, style: s = {}, outline }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      background: outline ? "transparent" : disabled ? "#E5E7EB" : color,
      color: outline ? color : disabled ? "#9CA3AF" : "#fff",
      border: outline ? `2px solid ${color}` : "none",
      borderRadius: 12, padding: "10px 18px", fontWeight: 700, fontSize: 13,
      cursor: disabled ? "default" : "pointer", transition: "all 0.18s",
      fontFamily: "inherit", ...s,
    }}>{children}</button>
  );
}

// ============================================================
// MONTHLY CHART COMPONENT
// ============================================================
function MonthlyChart({ history, dark }) {
  const sub = dark ? "#9CA3AF" : "#6B7280";
  const card = dark ? "#1F2937" : "#F9FAFB";

  const days = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    days.push(d.toISOString().slice(0, 10));
  }

  const maxH = 60;

  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 14, letterSpacing: 1, textTransform: "uppercase" }}>
        آخر 30 يوم
      </div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: maxH + 20 }}>
        {days.map((d, i) => {
          const entry = history?.[d];
          const pct = entry ? Math.round((entry.doneTasks / entry.totalTasks) * 100) : 0;
          const h = pct > 0 ? Math.max(6, Math.round((pct / 100) * maxH)) : 3;
          const col = pct === 100 ? "#10B981" : pct > 0 ? "#F59E0B" : (dark ? "#374151" : "#E5E7EB");
          const isToday = d === todayKey();
          return (
            <div key={d} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              <div
                title={`${d}: ${pct}%`}
                style={{
                  width: "100%", height: h, borderRadius: 3,
                  background: col,
                  outline: isToday ? `2px solid #6366F1` : "none",
                  transition: "height 0.3s",
                  cursor: "default",
                }}
              />
              {(i === 0 || i === 14 || i === 29) && (
                <div style={{ fontSize: 8, color: sub, whiteSpace: "nowrap" }}>{d.slice(5)}</div>
              )}
            </div>
          );
        })}
      </div>
      <div style={{ display: "flex", gap: 12, marginTop: 10, fontSize: 11, color: sub }}>
        <span><span style={{ color: "#10B981" }}>■</span> مكتمل</span>
        <span><span style={{ color: "#F59E0B" }}>■</span> جزئي</span>
        <span><span style={{ color: dark ? "#374151" : "#E5E7EB" }}>■</span> غايب</span>
      </div>
    </div>
  );
}

// ============================================================
// BADGES VIEW COMPONENT
// ============================================================
function BadgesSection({ userData, dark }) {
  const sub = dark ? "#9CA3AF" : "#6B7280";
  const txt = dark ? "#F9FAFB" : "#111827";
  const earnedIds = new Set(getEarnedBadges(userData).map(b => b.id));

  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 12, letterSpacing: 1, textTransform: "uppercase" }}>
        الإنجازات — {earnedIds.size}/{BADGES.length}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
        {BADGES.map(b => {
          const earned = earnedIds.has(b.id);
          return (
            <div key={b.id} style={{
              borderRadius: 14, padding: "12px 8px", textAlign: "center",
              background: earned ? (dark ? "#1F2937" : "#fff") : (dark ? "#111827" : "#F9FAFB"),
              border: `1.5px solid ${earned ? "#6366F144" : (dark ? "#1F2937" : "#F3F4F6")}`,
              opacity: earned ? 1 : 0.45,
              transition: "all 0.2s",
            }}>
              <div style={{ fontSize: 26, marginBottom: 4, filter: earned ? "none" : "grayscale(1)" }}>{b.icon}</div>
              <div style={{ fontSize: 11, fontWeight: 700, color: earned ? txt : sub, lineHeight: 1.3 }}>{b.name}</div>
              <div style={{ fontSize: 9.5, color: sub, marginTop: 3, lineHeight: 1.4 }}>{b.desc}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// NEW BADGE TOAST
// ============================================================
function BadgeToast({ badge, onClose }) {
  useEffect(() => {
    const t = setTimeout(onClose, 4000);
    return () => clearTimeout(t);
  }, [onClose]);
  return (
    <div style={{
      position: "fixed", top: 20, left: "50%", transform: "translateX(-50%)",
      background: "linear-gradient(135deg, #6366F1, #7C3AED)",
      color: "#fff", borderRadius: 18, padding: "14px 22px",
      boxShadow: "0 8px 32px #6366F155", zIndex: 9999,
      display: "flex", alignItems: "center", gap: 12, minWidth: 260, maxWidth: 340,
      animation: "slideDown 0.4s ease",
    }}>
      <span style={{ fontSize: 32 }}>{badge.icon}</span>
      <div>
        <div style={{ fontSize: 11, opacity: 0.85, marginBottom: 2 }}>🎉 إنجاز جديد!</div>
        <div style={{ fontWeight: 800, fontSize: 15 }}>{badge.name}</div>
        <div style={{ fontSize: 12, opacity: 0.85 }}>{badge.desc}</div>
      </div>
    </div>
  );
}

// ============================================================
// STEP CARD
// ============================================================
function StepCard({ step, color, accent, idx, total, checked, onCheck, active, onOpen, dark, notes, onNoteChange }) {
  const t = useTimer(step.mins);
  const allDone = step.tasks.every((_, i) => checked[i]);
  const doneCnt = step.tasks.filter((_, i) => checked[i]).length;
  const bg = dark ? (active ? "#1E1B4B" : "#111827") : (active ? "#fff" : "#F9FAFB");
  const border = active ? color : dark ? "#374151" : "#E5E7EB";
  const txt = dark ? "#F9FAFB" : "#111827";
  const sub = dark ? "#9CA3AF" : "#6B7280";

  return (
    <div onClick={!active ? onOpen : undefined} style={{
      background: bg, border: `2px solid ${border}`, borderRadius: 16, marginBottom: 12,
      overflow: "hidden", cursor: active ? "default" : "pointer", transition: "all 0.22s",
      boxShadow: active ? `0 6px 28px ${color}28` : "none",
    }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "14px 16px" }}>
        <div style={{
          width: 44, height: 44, borderRadius: 12, fontSize: 22, flexShrink: 0,
          background: active ? color : dark ? "#1F2937" : "#F3F4F6",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>{step.icon}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            <span style={{ fontWeight: 700, fontSize: 15, color: active ? color : txt }}>{step.title}</span>
            <Badge color={active ? color : sub}>{step.mins} د</Badge>
            {allDone && <span>✅</span>}
          </div>
          <div style={{ color: sub, fontSize: 12.5, marginTop: 2 }}>{step.subtitle}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
          <span style={{ color: sub, fontSize: 11 }}>{idx + 1}/{total}</span>
          <div style={{ background: dark ? "#1F2937" : "#F3F4F6", borderRadius: 999, width: 40, height: 4 }}>
            <div style={{ width: `${(doneCnt / step.tasks.length) * 100}%`, height: "100%", background: color, borderRadius: 999, transition: "width 0.3s" }} />
          </div>
        </div>
      </div>

      {/* Expanded Body */}
      {active && (
        <div style={{ padding: "0 16px 16px" }}>
          {/* Timer */}
          <div style={{
            background: dark ? "#0F172A" : color + "0D", border: `1px solid ${color}33`,
            borderRadius: 14, padding: 16, display: "flex", alignItems: "center", gap: 14, marginBottom: 14,
          }}>
            <div style={{ position: "relative" }}>
              <Ring secs={t.secs} total={t.total} color={color} size={60} />
              {t.done && <div style={{
                position: "absolute", inset: 0, display: "flex", alignItems: "center",
                justifyContent: "center", fontSize: 18,
              }}>✓</div>}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 32, fontWeight: 900, color, fontVariantNumeric: "tabular-nums", lineHeight: 1 }}>{t.fmt}</div>
              <div style={{ color: sub, fontSize: 11, marginTop: 3 }}>
                {t.done ? "خلصت! 🎉" : t.on ? "شغّال..." : "اضغط ابدأ"}
              </div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <Btn onClick={t.toggle} disabled={t.done} color={t.done ? "#10B981" : t.on ? "#F59E0B" : color}
                style={{ padding: "9px 16px", fontSize: 13 }}>
                {t.done ? "✓ تم" : t.on ? "⏸ وقّف" : "▶ ابدأ"}
              </Btn>
              <Btn onClick={t.reset} outline color={sub} style={{ padding: "9px 12px", fontSize: 13 }}>↩</Btn>
            </div>
          </div>

          {/* Details */}
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 8, letterSpacing: 1, textTransform: "uppercase" }}>الخطوات</div>
            {step.details.map((d, i) => (
              <div key={i} style={{ display: "flex", gap: 10, marginBottom: 8, direction: "rtl" }}>
                <span style={{ width: 20, height: 20, borderRadius: "50%", background: color + "22", color, fontSize: 11, fontWeight: 800, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>{i + 1}</span>
                <span style={{ fontSize: 13.5, color: txt, lineHeight: 1.6 }}>{d}</span>
              </div>
            ))}
          </div>

          {/* Tip */}
          <div style={{ background: "#FFFBEB", border: "1px solid #FDE68A", borderRight: `3px solid #F59E0B`, borderRadius: 8, padding: "8px 12px", marginBottom: 14, fontSize: 12.5, color: "#92400E", direction: "rtl" }}>
            💡 <strong>تيب:</strong> {step.tip}
          </div>

          {/* Sites */}
          {step.sites.length > 0 && (
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 8, letterSpacing: 1, textTransform: "uppercase" }}>مواقع مفيدة</div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {step.sites.map((s, i) => (
                  <a key={i} href={s.url} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}
                    style={{ background: color, color: "#fff", borderRadius: 20, padding: "7px 16px", fontSize: 13, fontWeight: 600, textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 6 }}>
                    🔗 {s.name}
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Checklist */}
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 8, letterSpacing: 1, textTransform: "uppercase" }}>تأكيد الإنجاز</div>
            {step.tasks.map((task, i) => (
              <div key={i} onClick={() => onCheck(i)} style={{
                display: "flex", alignItems: "center", gap: 10, direction: "rtl",
                padding: "9px 10px", borderRadius: 10, marginBottom: 6, cursor: "pointer",
                background: checked[i] ? color + "14" : dark ? "#1F2937" : "#F9FAFB",
                border: `1px solid ${checked[i] ? color + "55" : dark ? "#374151" : "#E5E7EB"}`,
                transition: "all 0.15s",
              }}>
                <div style={{ width: 20, height: 20, borderRadius: 6, border: `2px solid ${checked[i] ? color : "#D1D5DB"}`, background: checked[i] ? color : "transparent", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.15s" }}>
                  {checked[i] && <span style={{ color: "#fff", fontSize: 12, fontWeight: 800 }}>✓</span>}
                </div>
                <span style={{ fontSize: 13, color: checked[i] ? color : txt, fontWeight: checked[i] ? 600 : 400 }}>{task}</span>
              </div>
            ))}
          </div>

          {/* Notes */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 8, letterSpacing: 1, textTransform: "uppercase" }}>ملاحظات + كلمات جديدة</div>
            <textarea value={notes || ""} onChange={e => onNoteChange(e.target.value)}
              onClick={e => e.stopPropagation()}
              placeholder={`اكتب هنا الكلمات الجديدة أو ملاحظاتك على "${step.title}"...`}
              style={{
                width: "100%", minHeight: 80, padding: "10px 12px", borderRadius: 10,
                border: `1.5px solid ${dark ? "#374151" : "#E5E7EB"}`, fontSize: 13, resize: "vertical",
                background: dark ? "#0F172A" : "#F9FAFB", color: txt, fontFamily: "inherit",
                boxSizing: "border-box", outline: "none", direction: "rtl", lineHeight: 1.6,
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// LEADERBOARD COMPONENT
// ============================================================
function Leaderboard({ dark }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const txt = dark ? "#F9FAFB" : "#111827";
  const sub = dark ? "#9CA3AF" : "#6B7280";
  const card = dark ? "#1F2937" : "#fff";

  useEffect(() => {
    fbGetAll("users").then(data => {
      const sorted = data.sort((a, b) => (b.streak || 0) - (a.streak || 0));
      setUsers(sorted);
      setLoading(false);
    });
  }, []);

  const medals = ["🥇", "🥈", "🥉"];

  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 12, letterSpacing: 1, textTransform: "uppercase" }}>Leaderboard — الـ Streak</div>
      {loading ? (
        <div style={{ textAlign: "center", color: sub, padding: 20 }}>بيحمّل...</div>
      ) : users.length === 0 ? (
        <div style={{ textAlign: "center", color: sub, padding: 20 }}>لسه مفيش يوزرز</div>
      ) : users.map((u, i) => (
        <div key={u.id} style={{
          background: card, border: `1.5px solid ${i === 0 ? "#F59E0B44" : dark ? "#374151" : "#F3F4F6"}`,
          borderRadius: 12, padding: "12px 14px", marginBottom: 8,
          display: "flex", alignItems: "center", gap: 12,
        }}>
          <span style={{ fontSize: 20, width: 28, textAlign: "center" }}>{medals[i] || `${i + 1}`}</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 14, color: txt }}>{u.name}</div>
            <div style={{ fontSize: 11, color: sub }}>
              {ROUTINES[u.level]?.label || "مبتدئ"} — {u.totalDays || 0} يوم إجمالي
            </div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 20, fontWeight: 900, color: "#F59E0B" }}>{u.streak || 0}</div>
            <div style={{ fontSize: 10, color: sub }}>🔥 streak</div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ============================================================
// WEEKLY VIEW COMPONENT
// ============================================================
function WeeklyView({ history, dark }) {
  const sub = dark ? "#9CA3AF" : "#6B7280";
  const card = dark ? "#1F2937" : "#F9FAFB";
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    days.push(d.toISOString().slice(0, 10));
  }
  const dayNames = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 12, letterSpacing: 1, textTransform: "uppercase" }}>آخر 7 أيام</div>
      <div style={{ display: "flex", gap: 6, justifyContent: "space-between" }}>
        {days.map(d => {
          const entry = history?.[d];
          const pct = entry ? Math.round((entry.doneTasks / entry.totalTasks) * 100) : 0;
          const col = pct === 100 ? "#10B981" : pct > 0 ? "#F59E0B" : sub;
          const dayName = dayNames[new Date(d + "T00:00:00").getDay()];
          return (
            <div key={d} style={{ flex: 1, textAlign: "center" }}>
              <div style={{ fontSize: 10, color: sub, marginBottom: 6 }}>{dayName.slice(0, 3)}</div>
              <div style={{
                width: "100%", aspectRatio: "1", borderRadius: 10, background: pct > 0 ? col + "33" : card,
                border: `2px solid ${pct > 0 ? col : dark ? "#374151" : "#E5E7EB"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: pct === 100 ? 18 : 13, fontWeight: 800, color: col,
              }}>
                {pct === 100 ? "✅" : pct > 0 ? `${pct}%` : "–"}
              </div>
              <div style={{ fontSize: 9, color: sub, marginTop: 4 }}>{d.slice(5)}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// VOCAB LOG COMPONENT
// ============================================================
function VocabLog({ history, dark }) {
  const sub = dark ? "#9CA3AF" : "#6B7280";
  const txt = dark ? "#F9FAFB" : "#111827";
  const card = dark ? "#1F2937" : "#F9FAFB";
  const allNotes = [];
  Object.entries(history || {}).sort((a, b) => b[0].localeCompare(a[0])).forEach(([date, entry]) => {
    if (entry.notes) {
      Object.entries(entry.notes).forEach(([stepId, note]) => {
        if (note?.trim()) allNotes.push({ date, stepId, note });
      });
    }
  });
  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 12, letterSpacing: 1, textTransform: "uppercase" }}>سجل الملاحظات والكلمات</div>
      {allNotes.length === 0 ? (
        <div style={{ textAlign: "center", color: sub, padding: 24, fontSize: 13 }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>📝</div>
          لسه مفيش ملاحظات — اكتب في كل خطوة وهتظهر هنا
        </div>
      ) : allNotes.map((n, i) => (
        <div key={i} style={{ background: card, border: `1px solid ${dark ? "#374151" : "#E5E7EB"}`, borderRadius: 12, padding: "12px 14px", marginBottom: 10 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <Badge color="#6366F1">{n.stepId}</Badge>
            <span style={{ fontSize: 11, color: sub }}>{n.date}</span>
          </div>
          <div style={{ fontSize: 13.5, color: txt, lineHeight: 1.7, direction: "rtl", whiteSpace: "pre-wrap" }}>{n.note}</div>
        </div>
      ))}
    </div>
  );
}

// ============================================================
// MAIN APP
// ============================================================
export default function App() {
  const [screen, setScreen] = useState("login");
  const [tab, setTab] = useState("home");
  const [nameInput, setNameInput] = useState("");
  const [userId, setUserId] = useState("");
  const [userData, setUserData] = useState(null);
  const [level, setLevel] = useState("beginner");
  const [loading, setLoading] = useState(false);
  const [dark, setDark] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [checks, setChecks] = useState({});
  const [notes, setNotes] = useState({});
  const [saved, setSaved] = useState(false);
  const [saveMsg, setSaveMsg] = useState("");
  const [sessionRestored, setSessionRestored] = useState(false);
  const [newBadge, setNewBadge] = useState(null);
  const [freezeMsg, setFreezeMsg] = useState("");

  const routine = ROUTINES[level];
  const today = todayKey();

  const bg = dark ? "#0F172A" : "#EEF2FF";
  const bg2 = dark ? "#111827" : "#F5F3FF";
  const card = dark ? "#1F2937" : "#fff";
  const txt = dark ? "#F9FAFB" : "#111827";
  const sub = dark ? "#9CA3AF" : "#6B7280";
  const border = dark ? "#374151" : "#E5E7EB";

  // Restore session from localStorage
  useEffect(() => {
    if (screen === "session" && !sessionRestored) {
      const saved = localStorage.getItem(`session_${userId}_${today}`);
      if (saved) {
        try {
          const { checks: c, notes: n, activeStep: a } = JSON.parse(saved);
          if (c) setChecks(c);
          if (n) setNotes(n);
          if (a !== undefined) setActiveStep(a);
        } catch {}
      }
      setSessionRestored(true);
    }
  }, [screen, userId, today, sessionRestored]);

  // Persist session to localStorage
  useEffect(() => {
    if (screen === "session" && userId) {
      localStorage.setItem(`session_${userId}_${today}`, JSON.stringify({ checks, notes, activeStep }));
    }
  }, [checks, notes, activeStep, screen, userId, today]);

  // Progress calc
  const totalTasks = routine.steps.reduce((s, st) => s + st.tasks.length, 0);
  const doneTasks = Object.values(checks).reduce((s, sc) => s + Object.values(sc).filter(Boolean).length, 0);
  const pct = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;
  const complete = pct === 100;

  // Check for new badges
  function checkNewBadges(oldData, newData) {
    const oldEarned = new Set(getEarnedBadges(oldData).map(b => b.id));
    const newEarned = getEarnedBadges(newData);
    const justEarned = newEarned.filter(b => !oldEarned.has(b.id));
    if (justEarned.length > 0) setNewBadge(justEarned[0]);
  }

  async function handleLogin() {
    if (!nameInput.trim()) return;
    setLoading(true);
    const id = nameInput.trim().toLowerCase().replace(/\s+/g, "_");
    let data = await fbGet(`users/${id}`);
    if (!data) {
      data = { name: nameInput.trim(), level: "beginner", history: {}, streak: 0, lastDay: "", totalDays: 0, freezes: 1, freezesUsed: 0 };
      await fbSet(`users/${id}`, data);
    }
    // ensure freeze fields exist for old accounts
    if (data.freezes === undefined) data.freezes = 1;
    if (data.freezesUsed === undefined) data.freezesUsed = 0;
    setUserId(id); setUserData(data);
    setLevel(data.level || "beginner");
    setLoading(false); setScreen("main");
  }

  function startSession() {
    setActiveStep(0); setChecks({}); setNotes({});
    setSaved(false); setSaveMsg(""); setSessionRestored(false);
    setTab("session");
  }

  function handleCheck(stepId, ti) {
    setChecks(p => ({ ...p, [stepId]: { ...(p[stepId] || {}), [ti]: !(p[stepId] || {})[ti] } }));
  }
  function handleNote(stepId, val) {
    setNotes(p => ({ ...p, [stepId]: val }));
  }

  async function saveSession() {
    if (!userData) return;
    setLoading(true); setSaveMsg("بيحفظ...");

    const history = { ...(userData.history || {}), [today]: { level, doneTasks, totalTasks, notes, completedAt: new Date().toISOString() } };
    const yest = new Date(); yest.setDate(yest.getDate() - 1);
    const yKey = yest.toISOString().slice(0, 10);

    let streak = userData.streak || 0;
    let freezes = userData.freezes ?? 1;
    let freezesUsed = userData.freezesUsed || 0;
    let usedFreeze = false;

    if (userData.lastDay === yKey) {
      streak++;
    } else if (userData.lastDay === today) {
      // already saved today, no change
    } else if (userData.lastDay) {
      // missed at least one day — use freeze if available
      if (freezes > 0) {
        freezes--;
        freezesUsed++;
        streak++;
        usedFreeze = true;
      } else {
        streak = 1;
      }
    } else {
      streak = 1;
    }

    // earn a freeze every 10 total days
    const newTotalDays = Object.keys(history).length;
    if (newTotalDays > 0 && newTotalDays % 10 === 0 && (userData.totalDays || 0) < newTotalDays) {
      freezes++;
    }

    const nd = { ...userData, history, streak, lastDay: today, totalDays: newTotalDays, level, freezes, freezesUsed };
    const ok = await fbSet(`users/${userId}`, nd);

    checkNewBadges(userData, nd);
    setUserData(nd);
    setLoading(false);
    setSaved(true);

    let msg = ok ? "✅ اتحفظ على Firebase!" : "⚠️ تأكد من الـ Firebase config";
    if (usedFreeze) msg += " — 🧊 استخدمت Streak Freeze!";
    setSaveMsg(msg);
    if (usedFreeze) setFreezeMsg("🧊 Streak Freeze اتستخدم — streak محفوظ!");
    localStorage.removeItem(`session_${userId}_${today}`);
  }

  async function changeLevel(lv) {
    setLevel(lv);
    if (userId) {
      const nd = { ...userData, level: lv };
      setUserData(nd);
      checkNewBadges(userData, nd);
      await fbSet(`users/${userId}`, nd);
    }
  }

  const streak = userData?.streak || 0;
  const totalDays = userData?.totalDays || 0;
  const todayDone = userData?.history?.[today];
  const history = userData?.history || {};
  const freezes = userData?.freezes ?? 1;

  // ── LOGIN ──
  if (screen === "login") return (
    <div style={{ minHeight: "100vh", background: `linear-gradient(135deg, ${bg} 0%, ${bg2} 100%)`, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ width: "100%", maxWidth: 380 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 52, marginBottom: 12 }}>📚</div>
          <h1 style={{ fontSize: 28, fontWeight: 900, color: "#6366F1", margin: 0, letterSpacing: -1 }}>English Tracker</h1>
          <p style={{ color: sub, fontSize: 14, marginTop: 8 }}>تتبع تقدمك اليومي في تعلم الإنجليزي</p>
        </div>
        <div style={{ background: card, borderRadius: 24, padding: 28, boxShadow: "0 8px 48px #6366F122" }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: txt, marginBottom: 8, direction: "rtl" }}>اسمك إيه؟</div>
          <input value={nameInput} onChange={e => setNameInput(e.target.value)} onKeyDown={e => e.key === "Enter" && handleLogin()}
            placeholder="اكتب اسمك هنا..."
            style={{ width: "100%", padding: "13px 14px", borderRadius: 12, border: `2px solid ${border}`, fontSize: 15, outline: "none", boxSizing: "border-box", direction: "rtl", fontFamily: "inherit", background: "transparent", color: txt }} />
          <Btn onClick={handleLogin} disabled={loading || !nameInput.trim()} color="#6366F1"
            style={{ marginTop: 14, width: "100%", padding: "14px 0", fontSize: 15, borderRadius: 14, boxShadow: "0 4px 18px #6366F144" }}>
            {loading ? "بيدخل..." : "ابدأ →"}
          </Btn>
          <p style={{ textAlign: "center", color: sub, fontSize: 12, marginTop: 12 }}>لو اسمك موجود هيرجعلك تقدمك</p>
        </div>
      </div>
    </div>
  );

  // ── MAIN SHELL ──
  const NAV = [
    { key: "home",        icon: "🏠", label: "الرئيسية" },
    { key: "session",     icon: "▶️", label: "سيشن" },
    { key: "history",     icon: "📅", label: "السجل" },
    { key: "leaderboard", icon: "🏆", label: "Leaderboard" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: `linear-gradient(160deg, ${bg} 0%, ${bg2} 100%)`, direction: "rtl", fontFamily: "'Segoe UI', Tahoma, Arial, sans-serif" }}>

      {/* Badge Toast */}
      {newBadge && <BadgeToast badge={newBadge} onClose={() => setNewBadge(null)} />}

      {/* Top bar */}
      <div style={{ position: "sticky", top: 0, zIndex: 100, background: dark ? "#0F172A" : "rgba(238,242,255,0.9)", backdropFilter: "blur(12px)", borderBottom: `1px solid ${border}`, padding: "12px 20px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontSize: 20 }}>📚</div>
        <div style={{ fontWeight: 800, fontSize: 16, color: "#6366F1" }}>English Tracker</div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <span style={{ fontSize: 12, color: sub, fontWeight: 600 }}>🔥 {streak}</span>
          {freezes > 0 && <span title={`${freezes} Freeze متاح`} style={{ fontSize: 12, color: "#3B82F6", fontWeight: 700 }}>🧊{freezes}</span>}
          <button onClick={() => setDark(d => !d)} style={{ background: "none", border: `1.5px solid ${border}`, borderRadius: 8, padding: "5px 10px", cursor: "pointer", fontSize: 16 }}>
            {dark ? "☀️" : "🌙"}
          </button>
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: 520, margin: "0 auto", padding: "20px 16px 100px" }}>

        {/* HOME */}
        {tab === "home" && (
          <div>
            <div style={{ marginBottom: 20 }}>
              <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: txt }}>أهلاً {userData?.name} 👋</h2>
              <p style={{ margin: "4px 0 0", color: sub, fontSize: 13 }}>{new Date().toLocaleDateString("ar-EG", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
            </div>

            {/* Freeze message */}
            {freezeMsg && (
              <div style={{ background: "#EFF6FF", border: "1px solid #BFDBFE", borderRadius: 12, padding: "10px 14px", marginBottom: 12, color: "#1D4ED8", fontSize: 13, fontWeight: 600, display: "flex", gap: 8, alignItems: "center" }}>
                {freezeMsg}
                <button onClick={() => setFreezeMsg("")} style={{ background: "none", border: "none", cursor: "pointer", marginRight: "auto", color: "#93C5FD", fontSize: 16 }}>×</button>
              </div>
            )}

            {/* Stats */}
            <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
              {[
                { icon: "🔥", label: "Streak", val: streak, color: "#F59E0B" },
                { icon: "📆", label: "إجمالي أيام", val: totalDays, color: "#6366F1" },
                { icon: todayDone ? "✅" : "⏳", label: "النهارده", val: todayDone ? "تم" : "لسه", color: todayDone ? "#10B981" : sub },
              ].map((s, i) => (
                <div key={i} style={{ background: card, border: `1.5px solid ${border}`, borderRadius: 14, padding: "14px 10px", flex: 1, textAlign: "center", boxShadow: "0 2px 8px #6366F10A" }}>
                  <div style={{ fontSize: 22 }}>{s.icon}</div>
                  <div style={{ fontSize: 20, fontWeight: 900, color: s.color, marginTop: 4 }}>{s.val}</div>
                  <div style={{ fontSize: 10, color: sub, marginTop: 2 }}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Weekly */}
            <div style={{ background: card, borderRadius: 16, padding: 16, marginBottom: 16, boxShadow: "0 2px 8px #6366F10A", border: `1px solid ${border}` }}>
              <WeeklyView history={history} dark={dark} />
            </div>

            {/* Badges */}
            <div style={{ background: card, borderRadius: 16, padding: 16, marginBottom: 16, boxShadow: "0 2px 8px #6366F10A", border: `1px solid ${border}` }}>
              <BadgesSection userData={userData} dark={dark} />
            </div>

            {/* Streak Freeze info */}
            <div style={{ background: dark ? "#1E3A5F" : "#EFF6FF", border: `1px solid ${dark ? "#1D4ED8" : "#BFDBFE"}`, borderRadius: 14, padding: "12px 14px", marginBottom: 16, display: "flex", alignItems: "center", gap: 12 }}>
              <span style={{ fontSize: 24 }}>🧊</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: dark ? "#93C5FD" : "#1D4ED8" }}>Streak Freeze</div>
                <div style={{ fontSize: 12, color: dark ? "#60A5FA" : "#3B82F6" }}>
                  {freezes > 0
                    ? `عندك ${freezes} Freeze متاح — بيتحفظ تلقائي لو فاتتك يوم`
                    : "مفيش Freeze متاح — اكسب واحد كل 10 أيام"}
                </div>
              </div>
              <div style={{ fontWeight: 900, fontSize: 20, color: "#3B82F6" }}>{freezes}</div>
            </div>

            {/* Level */}
            <div style={{ background: card, borderRadius: 16, padding: 16, marginBottom: 16, boxShadow: "0 2px 8px #6366F10A", border: `1px solid ${border}` }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 10, letterSpacing: 1, textTransform: "uppercase" }}>مستواك</div>
              <div style={{ display: "flex", gap: 8 }}>
                {Object.entries(ROUTINES).map(([key, r]) => (
                  <button key={key} onClick={() => changeLevel(key)} style={{
                    flex: 1, padding: "11px 0", borderRadius: 12, border: `2px solid ${level === key ? r.color : border}`,
                    background: level === key ? r.color : "transparent", color: level === key ? "#fff" : sub,
                    fontWeight: 700, fontSize: 12, cursor: "pointer", transition: "all 0.2s", fontFamily: "inherit",
                  }}>
                    {r.label}<br /><span style={{ fontSize: 10, opacity: 0.8 }}>{r.levelEn}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Routine preview */}
            <div style={{ background: card, borderRadius: 16, padding: 16, marginBottom: 16, boxShadow: "0 2px 8px #6366F10A", border: `1px solid ${border}` }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 12, letterSpacing: 1, textTransform: "uppercase" }}>روتين النهارده</div>
              {routine.steps.map((s, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 0", borderBottom: i < routine.steps.length - 1 ? `1px solid ${border}` : "none" }}>
                  <span style={{ fontSize: 18 }}>{s.icon}</span>
                  <span style={{ flex: 1, fontSize: 13.5, color: txt, fontWeight: 500 }}>{s.title}</span>
                  <Badge color={routine.color}>{s.mins} د</Badge>
                </div>
              ))}
              <div style={{ marginTop: 10, paddingTop: 10, borderTop: `1px solid ${border}`, display: "flex", justifyContent: "space-between" }}>
                <span style={{ fontSize: 12, color: sub }}>إجمالي: {routine.totalMins} دقيقة</span>
                <span style={{ fontSize: 12, color: routine.color, fontWeight: 700 }}>{routine.steps.length} خطوات</span>
              </div>
            </div>

            <Btn onClick={startSession} color={routine.color}
              style={{ width: "100%", padding: "16px 0", fontSize: 17, borderRadius: 16, boxShadow: `0 6px 24px ${routine.color}44` }}>
              {todayDone ? "🔄 سيشن تاني النهارده" : "🚀 ابدأ روتين النهارده"}
            </Btn>
          </div>
        )}

        {/* SESSION */}
        {tab === "session" && (
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 18 }}>
              <Btn onClick={() => setTab("home")} outline color={sub} style={{ padding: "8px 14px", fontSize: 13 }}>← رجوع</Btn>
              <div style={{ flex: 1, fontWeight: 800, fontSize: 16, color: txt }}>سيشن — {routine.label}</div>
              <Badge color={routine.color}>{routine.totalMins} د</Badge>
            </div>

            {/* Overall progress */}
            <div style={{ background: card, borderRadius: 14, padding: "14px 16px", marginBottom: 16, border: `1px solid ${border}` }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                <span style={{ fontSize: 12, color: sub, fontWeight: 600 }}>التقدم الكلي</span>
                <span style={{ fontSize: 14, fontWeight: 900, color: routine.color }}>{pct}%</span>
              </div>
              <div style={{ background: dark ? "#1F2937" : "#F3F4F6", borderRadius: 999, height: 10, overflow: "hidden" }}>
                <div style={{ width: `${pct}%`, height: "100%", background: `linear-gradient(90deg, ${routine.color}, ${routine.accent})`, borderRadius: 999, transition: "width 0.4s ease" }} />
              </div>
              <div style={{ fontSize: 11, color: sub, marginTop: 6 }}>{doneTasks} / {totalTasks} مهمة مكتملة</div>
            </div>

            {/* Steps */}
            {routine.steps.map((step, i) => (
              <StepCard key={step.id} step={step} color={routine.color} accent={routine.accent}
                idx={i} total={routine.steps.length}
                checked={checks[step.id] || {}} onCheck={ti => handleCheck(step.id, ti)}
                active={activeStep === i} onOpen={() => setActiveStep(i)}
                dark={dark} notes={notes[step.id]} onNoteChange={v => handleNote(step.id, v)} />
            ))}

            {/* Save */}
            {complete && !saved && (
              <div>
                <div style={{ background: "#D1FAE5", border: "1px solid #6EE7B7", borderRadius: 14, padding: "14px 16px", textAlign: "center", marginBottom: 12, color: "#065F46", fontWeight: 700 }}>
                  🎉 أنهيت الروتين كله! احفظ تقدمك دلوقتي
                </div>
                <Btn onClick={saveSession} disabled={loading} color="#10B981" style={{ width: "100%", padding: "15px 0", fontSize: 16, borderRadius: 14, boxShadow: "0 4px 18px #10B98144" }}>
                  {loading ? "بيحفظ..." : "💾 احفظ اليوم ده"}
                </Btn>
              </div>
            )}
            {saved && (
              <div style={{ background: dark ? "#064E3B" : "#D1FAE5", border: "1px solid #6EE7B7", borderRadius: 14, padding: 20, textAlign: "center" }}>
                <div style={{ fontSize: 28, marginBottom: 6 }}>🔥</div>
                <div style={{ fontWeight: 800, fontSize: 16, color: "#065F46" }}>{saveMsg}</div>
                <div style={{ fontSize: 13, color: "#065F46", marginTop: 4 }}>Streak: {userData?.streak} يوم متتالي</div>
                <Btn onClick={() => setTab("home")} color="#10B981" style={{ marginTop: 14, padding: "10px 28px" }}>الرئيسية</Btn>
              </div>
            )}
            {!complete && (
              <div style={{ textAlign: "center", color: sub, fontSize: 12, marginTop: 8 }}>اضغط على كل خطوة تفتح التفاصيل والـ timer</div>
            )}
          </div>
        )}

        {/* HISTORY */}
        {tab === "history" && (
          <div>
            <h2 style={{ margin: "0 0 20px", fontSize: 20, fontWeight: 800, color: txt }}>📅 سجل الأيام</h2>

            {/* Monthly Chart */}
            <div style={{ background: card, borderRadius: 16, padding: 16, marginBottom: 16, border: `1px solid ${border}` }}>
              <MonthlyChart history={history} dark={dark} />
            </div>

            {/* Vocab log */}
            <div style={{ background: card, borderRadius: 16, padding: 16, marginBottom: 16, border: `1px solid ${border}` }}>
              <VocabLog history={history} dark={dark} />
            </div>

            {/* Days list */}
            <div style={{ fontSize: 11, fontWeight: 700, color: sub, marginBottom: 12, letterSpacing: 1, textTransform: "uppercase" }}>آخر 14 يوم</div>
            {Object.entries(history).length === 0 ? (
              <div style={{ textAlign: "center", color: sub, padding: 40, fontSize: 14 }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>📭</div>لسه مفيش سجل — ابدأ أول سيشن!
              </div>
            ) : Object.entries(history).sort((a, b) => b[0].localeCompare(a[0])).slice(0, 14).map(([date, entry]) => {
              const p = Math.round((entry.doneTasks / entry.totalTasks) * 100);
              const col = p === 100 ? "#10B981" : p > 50 ? "#F59E0B" : "#EF4444";
              return (
                <div key={date} style={{ background: card, border: `1.5px solid ${p === 100 ? "#6EE7B7" : border}`, borderRadius: 14, padding: "14px 16px", marginBottom: 10, display: "flex", alignItems: "center", gap: 14 }}>
                  <div style={{ width: 44, height: 44, borderRadius: 12, background: col + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>
                    {p === 100 ? "✅" : p > 50 ? "🔶" : "🔴"}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: 14, color: txt }}>{date}</div>
                    <div style={{ fontSize: 12, color: sub, marginTop: 2 }}>{entry.doneTasks}/{entry.totalTasks} مهام — {ROUTINES[entry.level]?.label || ""}</div>
                    <div style={{ marginTop: 6, background: dark ? "#1F2937" : "#F3F4F6", borderRadius: 999, height: 5 }}>
                      <div style={{ width: `${p}%`, height: "100%", background: col, borderRadius: 999 }} />
                    </div>
                  </div>
                  <div style={{ fontWeight: 900, fontSize: 18, color: col }}>{p}%</div>
                </div>
              );
            })}
          </div>
        )}

        {/* LEADERBOARD */}
        {tab === "leaderboard" && (
          <div>
            <h2 style={{ margin: "0 0 20px", fontSize: 20, fontWeight: 800, color: txt }}>🏆 Leaderboard</h2>
            <div style={{ background: card, borderRadius: 16, padding: 16, border: `1px solid ${border}` }}>
              <Leaderboard dark={dark} />
            </div>
          </div>
        )}
      </div>

      {/* Bottom Nav */}
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: dark ? "#0F172A" : "#fff", borderTop: `1px solid ${border}`, display: "flex", zIndex: 100, backdropFilter: "blur(12px)" }}>
        {NAV.map(n => (
          <button key={n.key} onClick={() => { if (n.key === "session") startSession(); else setTab(n.key); }}
            style={{ flex: 1, padding: "12px 0", background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <span style={{ fontSize: 20 }}>{n.icon}</span>
            <span style={{ fontSize: 10, fontWeight: tab === n.key ? 700 : 400, color: tab === n.key ? "#6366F1" : sub }}>{n.label}</span>
            {tab === n.key && <div style={{ width: 20, height: 3, background: "#6366F1", borderRadius: 999 }} />}
          </button>
        ))}
      </div>

      <style>{`
        @keyframes slideDown {
          from { opacity: 0; transform: translateX(-50%) translateY(-20px); }
          to   { opacity: 1; transform: translateX(-50%) translateY(0); }
        }
      `}</style>
    </div>
  );
}
